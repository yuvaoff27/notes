<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List</title>
    <script>
        const apiUrl = 'http://localhost/todo-app/routes/todo.php';

        async function fetchTodos() {
            const res = await fetch(apiUrl);
            const todos = await res.json();
            const todoList = document.getElementById('todo-list');
            todoList.innerHTML = '';
            todos.forEach(todo => {
                const li = document.createElement('li');
                li.textContent = `${todo.task} - ${todo.completed ? 'Done' : 'Not Done'}`;
                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = 'Delete';
                deleteBtn.onclick = () => deleteTodo(todo.id);
                li.appendChild(deleteBtn);
                todoList.appendChild(li);
            });
        }

        async function addTodo() {
            const taskInput = document.getElementById('task');
            const task = taskInput.value;
            const res = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ task })
            });
            const data = await res.json();
            console.log(data.message);
            taskInput.value = ''; // clear input
            fetchTodos();
        }

        async function deleteTodo(id) {
            const res = await fetch(`${apiUrl}?id=${id}`, { method: 'DELETE' });
            const data = await res.json();
            console.log(data.message);
            fetchTodos();
        }

        window.onload = fetchTodos;
    </script>
</head>
<body>
    <h1>Todo List</h1>
    <input type="text" id="task" placeholder="New Todo">
    <button onclick="addTodo()">Add Todo</button>

    <ul id="todo-list"></ul>
</body>
</html>
