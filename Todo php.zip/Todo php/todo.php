<?php
require_once '../config/db.php';

// GET all todos
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['id'])) {
    $stmt = $pdo->query("SELECT * FROM todos");
    $todos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($todos);
}

// GET single todo by ID
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM todos WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $todo = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($todo);
}

// POST create a new todo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    if (isset($data->task)) {
        $task = $data->task;
        $stmt = $pdo->prepare("INSERT INTO todos (task) VALUES (:task)");
        $stmt->bindParam(':task', $task);
        if ($stmt->execute()) {
            echo json_encode(['message' => 'Todo created successfully']);
        } else {
            echo json_encode(['message' => 'Failed to create todo']);
        }
    }
}

// PUT update a todo by ID
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $id = $_GET['id'];
    $data = json_decode(file_get_contents("php://input"));
    if (isset($data->task) || isset($data->completed)) {
        $task = $data->task ?? null;
        $completed = isset($data->completed) ? (int) $data->completed : null;
        
        if ($task) {
            $stmt = $pdo->prepare("UPDATE todos SET task = :task, updated_at = NOW() WHERE id = :id");
            $stmt->bindParam(':task', $task);
        }
        
        if ($completed !== null) {
            $stmt = $pdo->prepare("UPDATE todos SET completed = :completed, updated_at = NOW() WHERE id = :id");
            $stmt->bindParam(':completed', $completed);
        }

        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            echo json_encode(['message' => 'Todo updated successfully']);
        } else {
            echo json_encode(['message' => 'Failed to update todo']);
        }
    }
}

// DELETE a todo by ID
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM todos WHERE id = :id");
    $stmt->bindParam(':id', $id);
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Todo deleted successfully']);
    } else {
        echo json_encode(['message' => 'Failed to delete todo']);
    }
}
?>
